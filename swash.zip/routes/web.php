<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\LocationController;

Route::get('/', [LoginController::class, 'loginPage'])->name('login');
Route::get('login', [LoginController::class, 'loginPage'])->name('login');
Route::post('login-submit', [LoginController::class, 'loginSubmit'])->name('loginSubmit');

Route::group(['middleware' => 'prevent-back-history'], function () {
    Route::group(['middleware' => 'check-admin'], function () {
        Route::get('dashboard', [DashboardController::class, 'homeIndex'])->name('dashboard');
        Route::get('logouta-admin', [LoginController::class, 'logoutAdmin'])->name('logoutAdmin');
        Route::resource('client', ClientController::class);
        Route::get('update-status/{id}', [ClientController::class, 'updateStatus'])->name('updateStatus');
        Route::resource('locations', LocationController::class);
        Route::get('locations/{id}',[ LocationController::class, 'delete'])->name('locations.delete');
    });
});


