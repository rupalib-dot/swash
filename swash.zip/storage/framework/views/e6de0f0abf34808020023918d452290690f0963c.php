<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
      <div class="col-md-5">

        <!-- Profile Image -->
        <div class="card card-primary card-outline">
          <div class="card-body box-profile">
            <div class="text-center">
              <img class="profile-user-img img-fluid img-circle" style="height: 150px; width: 150px"
                   src="<?php if($client->photo != null): ?><?php echo e(asset('public/storage/image/'.$client->photo)); ?><?php else: ?><?php echo e(asset('public/dist/img/user4-128x128.jpg')); ?>

                   <?php endif; ?>" alt="User profile picture">
            </div>

            <h3 class="profile-username text-center"><?php echo e($client->name); ?></h3>

            <ul class="list-group list-group-unbordered mb-3">
              <li class="list-group-item">
                <b>Email</b> <a class="float-right"><?php echo e($client->email); ?></a>
              </li>
              <li class="list-group-item">
                <b>Phone</b> <a class="float-right"><?php echo e($client->phone); ?></a>
              </li>
              <li class="list-group-item">
                <b>Number of Booking</b> <a class="float-right">0</a>
              </li>
            </ul>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->

      </div>
      <!-- /.col -->
      <div class="col-md-7">
        <div class="card">
            <div class="card-body">
                <h3 class="para-family heading-bottom text-center">Edit client account</h3>
                <?php echo $__env->make('inc.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <br>
                <form action="<?php echo e(route('client.update', isset($client) ? base64_encode($client->id) : base64_encode(0) )); ?>" method="POST" enctype="multipart/form-data" id="general_form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group col-12">
                        <input type="hidden" name="id" value="<?php echo e($client->id); ?>">
                        <input type="text" class="form-control" value="<?php echo e(old('name', isset($client) ? $client->name : '')); ?>" name="name" aria-describedby="emailHelp"
                            placeholder="Full Name" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-12">

                        <input type="tel" class="form-control" value="<?php echo e(old('phone', isset($client) ? $client->phone : '')); ?>" name="phone" minlength="9" maxlength="11" aria-describedby="emailHelp" placeholder="Phone Number"
                            onkeypress="return isNumber(event)" required>
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-12">
                        <input type="email" value="<?php echo e(old('email', isset($client) ? $client->email : '')); ?>" class="form-control" name="email" id="exampleInputEmail1"
                            aria-describedby="emailHelp" placeholder="Enter email" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12">
                      <div class="form-group">
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file" name="image" class="custom-file-input" id="exampleInputFile">
                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                          </div>

                        </div>
                      </div>
                    </div>
                    <div class="text-left col-12">
                        <button type="submit" class="btn btn-primary btn-inline-block">Sign Up</button>
                    </div>
                </form>
            </div><!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.inc.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\swash\resources\views/admin/addclient.blade.php ENDPATH**/ ?>