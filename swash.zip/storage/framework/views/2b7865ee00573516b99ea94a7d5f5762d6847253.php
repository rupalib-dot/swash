<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card">

            <!-- /.card-header -->
            <div class="card-body">
                <?php echo $__env->make('inc.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php if(count($clients) > 0): ?>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($client->id); ?></td>
                                    <td><?php echo e($client->name); ?></td>
                                    <td><?php echo e($client->phone); ?></td>
                                    <td><?php echo e($client->email); ?></td>
                                    <td>
                                        <?php if($client->status == 'active'): ?>
                                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('updateStatus',base64_encode($client->id))); ?>">Deactive</a>
                                        <?php else: ?>
                                        <a class="btn btn-danger btn-sm" href="<?php echo e(route('updateStatus',base64_encode($client->id))); ?>">Active</a>
                                        <?php endif; ?>
                                        <a class="btn btn-success btn-sm" href="<?php echo e(route('client.edit',base64_encode($client->id))); ?>">View</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <td valign="top" colspan="5" class="dataTables_empty">No matching records found</td>
                            <?php endif; ?>

                    </tbody>

                </table>
            </div>
            <!-- /.card-body -->
        </div>

    </div><!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.inc.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\swash\resources\views/admin/clients.blade.php ENDPATH**/ ?>