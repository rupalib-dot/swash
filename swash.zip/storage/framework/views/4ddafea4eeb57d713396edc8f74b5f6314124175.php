<?php $__env->startSection('content'); ?>

    <div class="card-body" style="background-color: #fff">
        <?php echo $__env->make('inc.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table id="datatable" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>Location ID</th>
                    <th>Location Name</th>
                    <th>Location Address</th>
                    <th>Location Postcode</th>
                    <th>Location Capacity</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($locations) > 0 ): ?>
                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($location->id); ?> </td>
                        <td><?php echo e($location->name); ?> </td>
                        <td><?php echo e($location->address); ?> </td>
                        <td><?php echo e($location->postcode); ?> </td>
                        <td><?php echo e($location->capacity); ?> </td>
                        <td> <a href="<?php echo e(route('locations.edit',base64_encode($location->id))); ?>" class="btn btn-primary btn-sm">View</a>
                            <a href="<?php echo e(route('locations.delete',base64_encode($location->id))); ?>" class="btn btn-danger btn-sm">Delete</a> </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <td valign="top" colspan="6" class="dataTables_empty">No matching records found</td>
                <?php endif; ?>


            </tbody>
        </table>
    </div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.inc.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\swash\resources\views/admin/locations.blade.php ENDPATH**/ ?>