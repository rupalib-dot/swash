<?php if(Session::has('Failed')): ?>
<style>
    .text-danger {
    color: red;
    border: 1px solid red;
    padding: 5px 10px;
    border-radius: 3px;
    box-shadow: 0px 0px 5px;
}
</style>
<p class="text-danger"><?php echo e(Session::get('Failed')); ?></p>
<?php endif; ?>

<?php if(Session::has('Success')): ?>
<style>
    .text-success {
    color: #3c763d;
    border: 1px solid #3c763d;
    padding: 5px 10px;
    border-radius: 3px;
    box-shadow: 0px 0px 5px;
}
</style>
<p class="text-success"><?php echo e(Session::get('Success')); ?></p>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\swash\resources\views/inc/msg.blade.php ENDPATH**/ ?>